import time
import pandas as pd
import numpy as np

CITY_DATA = { 'ch': 'chicago.csv',
              'ny': 'new_york_city.csv',
              'w': 'washington.csv' }

def get_filters():
    print('Hello! Let\'s explore some US bikeshare data!')
    city = input("\n please enter the city as below:\n ch for chicago \n ny for new york city \n w for washington \n").lower()
    while city not in CITY_DATA.keys():
        print("\n try again with right city")
        city = input("\n please chose the city from below:\n ch for chicago \n ny for new york \n w for washington \n").lower()

    months = ['january', 'february', 'march', 'april', 'may', 'june', 'all']
    month = input('\n please chose month from the below: \n january \n february \n march \n april \n may \n june \n all \n').lower()
    while month not in months:
        print('wrong month try again!!')
        month = input('\n please chose month from the below: \n january \n february \n march \n april \n may \n june \n').lower()

    week = ['all', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'sunday']
    day = input("\n please chose day (type all to chose whole weekdays): \n").lower()
    while day not in week:
        print('\n wrong day please enter again!!')
        day = input("\n please chose day (type all to chose whole weekdays): \n").lower()


    print('-'*40)
    return city, month, day


def load_data(city, month, day):

    df = pd.read_csv(CITY_DATA[city])
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df['month'] = df['Start Time'].dt.month_name()
    df['start day'] = df['Start Time'].dt.day_name()
    df['start hour'] = df['Start Time'].dt.hour

    if month != "all":
        df = df[df["month"] == month.title()]
    if day != "all":
        df = df[df['start day'] == day.title()]

    return df


def time_stats(df):

    print('\nCalculating The Most Frequent Times of Travel...\n')

    # TO DO: display the most common month
    popular_month = df['month'].mode()[0]
    print("Most Frequent month: " + popular_month)


    # TO DO: display the most common day of week
    popular_day = df['start day'].mode()[0]
    print("Most Frequent day: " + popular_day)

    # TO DO: display the most common start hour
    popular_hour = df['start hour'].mode()[0]
    print("Most Frequent hour: " + str(popular_hour))


    print('-'*40)


def station_stats(df):

    print('\nCalculating The Most Popular Stations and Trip...\n')
    # TO DO: display most commonly used start station
    most_start = df['Start Station'].mode()[0]
    print("Most Popular Start Station: " + most_start)

    # TO DO: display most commonly used end station
    most_end = df['End Station'].mode()[0]
    print("Most Popular End Station: " + most_end)

    # TO DO: display most frequent combination of start station and end station trip
    df['route'] = 'from  ' + df['Start Station'] + '  to  ' + df['End Station']
    print("Most Frequent Route: " + df['route'].mode()[0])

    print('-'*40)


def trip_duration_stats(df):

    print('\nCalculating Trip Duration...\n')
    # TO DO: display total travel time
    df['End Time'] = pd.to_datetime(df['End Time'])
    df['trip_time'] = df['End Time'] - df['Start Time']
    total = df['trip_time'].sum()
    print("Total travel time: " + str(total))

    # TO DO: display mean travel time
    mean = df['trip_time'].mean()
    print("Average travel time: " + str(mean))


    print('-'*40)


def user_stats(df):

    print('\nCalculating User Stats...\n')

    # TO DO: Display counts of user types
    users_types = df['User Type'].value_counts()
    print('Users Types Count: \n' +  str(users_types))

    # TO DO: Display counts of gender
    if "Gender" in df :
        gender_count = df['Gender'].value_counts()
        print('Users Gender Count: \n' + str(gender_count))
    else:
        print("No gender data on this state")

    if 'Birth Year' in df:
        earliest = df['Birth Year'].max()
        print('Recent Birth Year: \n' + str(earliest))
        recent = df['Birth Year'].min()
        print('Earliest Birth Year: \n' + str(recent))
        common = df['Birth Year'].mode()[0]
        print('Most Common Birth Year: \n' + str(common))
    else:
        print("No birth year data on this state")



    print('-'*40)


def display_raw_data(df):

    print('\nRaw data is available to check... \n')
    loc = 0
    while True:
        raw = input('To View the raw data in 5 rows please type: Yes \n').lower()
        if raw not in ['yes', 'no']:
            print('That\'s invalid choice, pleas type yes or no')

        elif raw == 'yes':
            print(df.iloc[loc:loc+5])
            loc += 5


        elif raw == 'no':
            print('\nExiting...')
            break


def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)
        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)
        display_raw_data(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()
